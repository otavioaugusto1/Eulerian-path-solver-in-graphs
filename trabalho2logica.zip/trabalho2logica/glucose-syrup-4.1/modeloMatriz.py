def carregarGrafo():
    arquivo = open('grafoexemplo.txt', 'r')
    qtdArestasReal = int(arquivo.readline())
    qtdArestas = int(arquivo.readline())
    arestas = arquivo.readline()
    arestas = str(arestas)
    arestas = arestas.split(",")
    matriz = []
    for i in arestas:
        matriz.append(i.split(" "))
    print(matriz)
    arquivo.close()
    return qtdArestas, matriz, qtdArestasReal

qtdArestas, arestas, qtdArestasReal = carregarGrafo()


#Irei preencher o "entrada.txt"
def preencherArquivo():
    arquivo = open('entrada.txt', 'w+')

    #Garante Que a aresta vai ser utilizada
    for i in range(0, qtdArestas, 2):
        for j in range(0, qtdArestasReal, 1):
            arquivo.write(str(j + 1) + arestas[i][0] + arestas[i][1] + " " + str(j + 1) + arestas[i + 1][0] + arestas[i + 1][1] + " ")
        arquivo.write("\n")

    # #Garante que não vai ter volta
    #arquivo.write("Regra 2 \n")
    for i in range(0, qtdArestas, 1):
        for j in range(0, qtdArestasReal, 1):
            for k in range(0, qtdArestasReal, 1):
                if (i + 1) % 2 != 0:
                    arquivo.write("-" + str(j + 1) + arestas[i][0] + arestas[i][1] + " -" + str(k + 1) + arestas[i + 1][0] + arestas[i + 1][1] + "\n")
                else:
                    arquivo.write("-" + str(j + 1) + arestas[i][0] + arestas[i][1] + " -" + str(k + 1) + arestas[i - 1][0] + arestas[i - 1][1] + "\n")

    # #Garante que não vai ser utilizado em outra posição
    #arquivo.write("Regra 3 \n")
    for i in range(0, qtdArestas, 1):
        for j in range(0, qtdArestasReal, 1):
            for k in range(0, qtdArestasReal, 1):
                if j != k:
                    arquivo.write("-" + str(j + 1) + arestas[i][0] + arestas[i][1] + " -" + str(k + 1) + arestas[i][0] + arestas[i][1] + "\n")

    # #Garante que não vai ter nenhum na mesma posição que ele
    #arquivo.write("Regra 4 \n")
    for i in range(0, qtdArestasReal, 1):
        for j in range(0, qtdArestas, 1):
            for k in range(0, qtdArestas, 1):
                if j != k:
                    arquivo.write("-" + str(i + 1) + arestas[j][0] + arestas[j][1] + " -" + str(i + 1) + arestas[k][0] + arestas[k][1] + "\n")

    #arquivo.write("Regra 5 \n")
    for i in range(0, qtdArestas, 1):
        for k in range(0, qtdArestasReal, 1):
            if k < qtdArestasReal - 1:
                vetor = []
                for j in arestas:
                    if arestas[i][1] == j[0]:
                        vetor.append(j)
                clausula = "-" + str(k + 1) + arestas[i][0] + arestas[i][1]
                for j in vetor:
                    clausula += " " + str(k + 2) + j[0] + j[1]
                arquivo.write(clausula + "\n")






    arquivo.close()

preencherArquivo()
